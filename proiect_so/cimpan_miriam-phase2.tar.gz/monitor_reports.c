#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<signal.h>

#define PID_FILE ".monitor_pid"

void handle_signal(int sig) {
   if (sig == SIGUSR1) {
   const char msg[] = "Raport nou detectat!\n";
  write(STDOUT_FILENO, msg, sizeof(msg)-1); 
  //
  } else if (sig == SIGINT) {
  const char msg[] = "\nInchidere monitor si stergere fisier.\n";
  write(STDOUT_FILENO, msg, sizeof(msg)-1);
  unlink(PID_FILE); // Sterge fisierul .monitor_pid
  _exit(0);
}
}

int main(void)
{
  int fd = open(PID_FILE,O_WRONLY|O_CREAT|O_TRUNC,0644);
  if(fd == -1)
    {
      printf("eroare la creare fisierului");
      exit(EXIT_FAILURE);
    }
  char buffer[16];
  int len = sprintf(buffer,"%d",getpid());
  write(fd,buffer,len);
  close(fd);
  struct sigaction sa;
  //sigaction(signal type, struct sigaction(new), where to return the old handler info(old))
  sa.sa_handler = handle_signal;
  sigemptyset(&sa.sa_mask); //nu avem semnale blocate in timpul functiei handle_signal
  sa.sa_flags = 0;

 sigaction(SIGUSR1, &sa, NULL);
 sigaction(SIGINT, &sa, NULL);

 write(STDOUT_FILENO, "Monitor activ. Asteapta SIGUSR1 sau SIGINT...\n", 46);

 while (1) {
pause(); 
}

 
  return 0;
}
